#include <avr/pgmspace.h>
const prog_uchar string_0[] PROGMEM = "OK";
const prog_uchar string_1[] PROGMEM = "SD Missing";
const prog_uchar string_2[] PROGMEM = "Setting Filemissing";
const prog_uchar string_3[] PROGMEM = "GMT not in  Setting File";
const prog_uchar string_4[] PROGMEM = "Sunteams 1.1";


PROGMEM const unsigned char *string_table[] = 	   // change "string_table" name to suit
{   
  string_0,
  string_1,
  string_2,
  string_3,
  string_4
};
  


enum error_c {
   ALL_OK,
   FILE_SD_CARD,     //Could not open card
   FILE_SD_MISSING,  //Could not open File
   FILE_GMT_ERROR,   //GMT Offset missing from File
   VERSION,          //Version
   SOUTH_WIND, 
   EAST_WIND, 
   WEST_WIND
};


