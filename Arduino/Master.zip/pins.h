//serial debug
#define PL_DEBUG
//LCD Debug
//#define PL_DEBUG1


// Digital Pins
#define SERIAL_RX 15
#define SERIAL_TX 14
//#define PIN_SERIAL_GO 2
//#define Unused1   3
#define PIN_SD    4
#define PIN_SCE   5  // LCD CS  .... Pin 3
#define PIN_RESET 6  // LCD RST .... Pin 1
#define PIN_DC    7  // LCD Dat/Com. Pin 5
#define PIN_SDIN  8  // LCD SPIDat . Pin 6
#define PIN_SCLK  9  // LCD SPIClk . Pin 4
#define PIN_NET  10  // Network card
#define PIN_MOSI 11
#define PIN_MISO 12
#define PIN_SCK  13

// Analog Pins
#define P_A0 A0
#define P_A1 A1
#define P_A2 A2
#define P_A3 A3
#define P_A4 A4  //RTC via 1 wire
#define P_A5 A5  //RTC via 1 wire

#define DS1307_ADDRESS 0x68

#define RETURN_BUFFER 100
#define DATE_BUFFER 12

#define DISPLAY_DATE 0
#define DISPLAY_SERIAL 1
#define DISPLAY_TOT 3
#define DISPLAY_MEM  4
